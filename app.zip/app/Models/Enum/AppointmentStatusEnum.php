<?php

namespace App\Models\Enum;

class AppointmentStatusEnum
{
    const Pending = 0;
    const Done = 1;
}
